/* ==========================
   STYLED BY KAYE JAVASCRIPT
   ========================== */

/* -------- MOBILE MENU TOGGLE -------- */
const navToggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector("nav ul");

if (navToggle) {
  navToggle.addEventListener("click", () => {
    navMenu.classList.toggle("show-menu");
  });
}

/* -------- SMOOTH SCROLL FOR NAV LINKS -------- */
const navLinks = document.querySelectorAll("nav ul li a");

navLinks.forEach(link => {
  link.addEventListener("click", function (e) {
    if (this.hash !== "") {
      e.preventDefault();
      const target = document.querySelector(this.hash);
      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    }
  });
});

/* -------- FORM VALIDATION (Enquiry Page) -------- */
const enquiryForm = document.querySelector("form");

if (enquiryForm) {
  enquiryForm.addEventListener("submit", function (e) {
    const name = document.querySelector("#name");
    const email = document.querySelector("#email");
    const message = document.querySelector("#message");

    if (!name.value || !email.value || !message.value) {
      e.preventDefault();
      alert("Please fill in all fields before submitting.");
    }
  });
}
