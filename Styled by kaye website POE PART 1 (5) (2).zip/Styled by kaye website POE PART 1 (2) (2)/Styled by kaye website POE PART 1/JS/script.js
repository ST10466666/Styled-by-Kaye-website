/* ==========================
   MOBILE MENU TOGGLE
========================== */
const navToggle = document.querySelectorAll(".nav-toggle");
navToggle.forEach(toggle => {
  const navMenu = toggle.nextElementSibling;
  toggle.addEventListener("click", () => {
    navMenu.classList.toggle("show-menu");
    toggle.setAttribute("aria-expanded", navMenu.classList.contains("show-menu"));
  });
});

/* ==========================
   SMOOTH SCROLL
========================== */
const navLinks = document.querySelectorAll("nav ul li a");
navLinks.forEach(link => {
  link.addEventListener("click", function(e) {
    if(this.hash !== "") {
      e.preventDefault();
      const target = document.querySelector(this.hash);
      if(target) target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

/* ==========================
   FORM SUBMISSION MESSAGES
========================== */
const enquiryForm = document.querySelector("#enquiryForm");
const formMessage = document.querySelector(".form-message");

if (enquiryForm) {
  enquiryForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const name = document.querySelector("#name");
    const email = document.querySelector("#email");
    const phone = document.querySelector("#phone");

    if(!name.value || !email.value || !phone.value) {
      formMessage.textContent = "Please fill in all required fields before submitting.";
      formMessage.style.color = "#d437a7"; 
      formMessage.style.fontWeight = "600";
    } else {
      formMessage.textContent = "Thank you! We have received your enquiry and will get back to you soon.";
      formMessage.style.color = "#3c2f2f"; 
      formMessage.style.fontWeight = "600";
      enquiryForm.reset();
    }
  });
}

/* ==========================
   LIGHTBOX GALLERY FOR SERVICES
========================== */
const serviceItems = document.querySelectorAll('.service-item img');
let currentIndex = 0;

const lightbox = document.createElement('div');
lightbox.classList.add('lightbox');
lightbox.innerHTML = `
  <span class="close">&times;</span>
  <img class="lightbox-img" src="" alt="Service image">
  <div class="lightbox-controls">
    <span class="prev">&#10094;</span>
    <span class="next">&#10095;</span>
  </div>
`;
document.body.appendChild(lightbox);

const lightboxImg = lightbox.querySelector('.lightbox-img');
const closeBtn = lightbox.querySelector('.close');
const nextBtn = lightbox.querySelector('.next');
const prevBtn = lightbox.querySelector('.prev');

function showLightbox(index) {
  currentIndex = index;
  lightboxImg.src = serviceItems[currentIndex].src;
  lightbox.style.display = 'flex';
}

function closeLightbox() {
  lightbox.style.display = 'none';
}

function nextImage() {
  currentIndex = (currentIndex + 1) % serviceItems.length;
  lightboxImg.src = serviceItems[currentIndex].src;
}

function prevImage() {
  currentIndex = (currentIndex - 1 + serviceItems.length) % serviceItems.length;
  lightboxImg.src = serviceItems[currentIndex].src;
}

serviceItems.forEach((img, i) => {
  img.addEventListener('click', () => showLightbox(i));
});

closeBtn.addEventListener('click', closeLightbox);
nextBtn.addEventListener('click', nextImage);
prevBtn.addEventListener('click', prevImage);

// Close lightbox on outside click
lightbox.addEventListener('click', e => {
  if(e.target === lightbox) closeLightbox();
});
